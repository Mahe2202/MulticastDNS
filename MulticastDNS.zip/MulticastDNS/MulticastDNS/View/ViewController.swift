//
//  ViewController.swift
//  MulticastDNS
//
//  Created by Udhayakumar on 04/11/22.
//

import UIKit
import Pods_MulticastDNS

class ViewController: UIViewController, DiscoveryDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var discovery: Discovery?
    var service: NetService?
    
    var serviceDetails = [NetService]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        registerCell()

    }
    
    func registerCell() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "ScanerResultTableViewCell", bundle: nil), forCellReuseIdentifier: "ScanerResultTableViewCell")
    }

    @IBAction func publishAction(_ sender: Any) {
       
        publiching()
       
    }
    
    
    func publiching() {
        if UIDevice.current.userInterfaceIdiom == .phone {
            service = NetService(domain: "", type: "_http._tcp", name: "My iPhones", port: 80)
        }else {
            service = NetService(domain: "", type: "_http._tcp", name: "My iPad", port: 8080)
        }
        service?.publish()
        
    }
    
    @IBAction func scanAction(_ sender: Any) {
        scanService()
    }
    
    func scanService() {
        let discoveryConfiguration = DiscoveryConfiguration(serviceType: "_http._tcp", serviceNamePrefix: "My iPhones")
        
        guard let discovery = Discovery(with: [ discoveryConfiguration], delegate: self) else {
            return
        }
        
        self.discovery = discovery
        discovery.startDiscovery()
        
    }
    
    func discoveryDidDiscover(service: DiscoveryService) {
        serviceDetails.append(NetService(domain: service.netService.domain, type: service.netService.type, name: service.netService.name, port: Int32(service.netService.port)))
        self.tableView.reloadData()

        
    }
    
    func discoveryDidFail(configuration: DiscoveryConfiguration, error: DiscoveryError) {
        print("error",error)
    }
    
    func discoveryDidDisappear(service: DiscoveryService) {
        print("service discoveryDidDisappear",service)
    }
    
}

extension ViewController  : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return serviceDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ScanerResultTableViewCell") as! ScanerResultTableViewCell
        let details = serviceDetails[indexPath.row]
        cell.serviceName.text = "Service Name :  \(details.name)"
        cell.serviceType.text = "Service Name :  \(details.type) "
        cell.address.text = "Service Name :  \(details.domain)"
        cell.port.text =  "Service Name : \(details.port)"
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    

    
    
    
    
}
