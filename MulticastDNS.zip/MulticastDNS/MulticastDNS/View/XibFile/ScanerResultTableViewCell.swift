//
//  ScanerResultTableViewCell.swift
//  MulticastDNS
//
//  Created by Udhayakumar on 05/11/22.
//

import UIKit

class ScanerResultTableViewCell: UITableViewCell {
    
    @IBOutlet weak var serviceName: UILabel!
    @IBOutlet weak var serviceType: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var port: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
